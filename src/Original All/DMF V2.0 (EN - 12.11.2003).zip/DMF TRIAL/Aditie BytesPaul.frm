VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   3195
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4680
   LinkTopic       =   "Form1"
   ScaleHeight     =   3195
   ScaleWidth      =   4680
   StartUpPosition =   3  'Windows Default
   Begin VB.TextBox Text2 
      Height          =   375
      Left            =   600
      TabIndex        =   1
      Text            =   "200"
      Top             =   960
      Width           =   2535
   End
   Begin VB.TextBox Text1 
      Height          =   285
      Left            =   840
      TabIndex        =   0
      Text            =   "C:\windows\desktop\g2.exe"
      Top             =   480
      Width           =   3015
   End
   Begin VB.Label Label2 
      Caption         =   "Label2"
      Height          =   375
      Left            =   840
      TabIndex        =   3
      Top             =   2520
      Width           =   1575
   End
   Begin VB.Label Label1 
      Caption         =   "Label1"
      Height          =   495
      Left            =   480
      TabIndex        =   2
      Top             =   1680
      Width           =   3615
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Form_Load()
If Text1.Text <> "" And Text2.Text > 0 Then
fsiz = ShowFileSize(Text1.Text)
Label1.Caption = fsiz
Open Text1.Text For Binary As #1
For a = 1 To Text2.Text
Put #1, fsiz - 1, "Paul"
Next
Close
End If
End Sub



Function ShowFileSize(file)
    Dim fs, f, s
    Set fs = CreateObject("Scripting.FileSystemObject")
    Set f = fs.GetFile(file)
    ShowFileSize = f.Size
    's = UCase(f.Name) & " uses " & f.Size & " bytes."
    'MsgBox s, 0, "Folder Size Info"
End Function
'94208

Private Sub Label2_Click()
fsiz = ShowFileSize(Text1.Text)
Open Text1.Text For Binary As #1
Get #1, (fsiz), tt
Label2.Caption = tt
Close

End Sub
