VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form Form1 
   BorderStyle     =   4  'Fixed ToolWindow
   Caption         =   "Cracking Engine"
   ClientHeight    =   1470
   ClientLeft      =   45
   ClientTop       =   315
   ClientWidth     =   5550
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   1470
   ScaleWidth      =   5550
   ShowInTaskbar   =   0   'False
   StartUpPosition =   3  'Windows Default
   Begin VB.Frame Frame1 
      Caption         =   "Speed"
      Height          =   615
      Left            =   120
      TabIndex        =   5
      Top             =   720
      Width           =   3975
      Begin MSComctlLib.Slider Slider1 
         Height          =   255
         Left            =   120
         TabIndex        =   6
         Top             =   240
         Width           =   3735
         _ExtentX        =   6588
         _ExtentY        =   450
         _Version        =   393216
         LargeChange     =   1
         Max             =   300
         SelStart        =   10
         TickStyle       =   3
         TickFrequency   =   0
         Value           =   10
      End
   End
   Begin VB.TextBox Text2 
      Height          =   285
      Left            =   120
      TabIndex        =   2
      Text            =   "pass"
      Top             =   360
      Width           =   3975
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Stop"
      Height          =   255
      Left            =   4200
      TabIndex        =   1
      Top             =   360
      Width           =   1215
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Start"
      Height          =   255
      Left            =   4200
      TabIndex        =   0
      Top             =   720
      Width           =   1215
   End
   Begin VB.Timer Timer1 
      Enabled         =   0   'False
      Interval        =   5
      Left            =   1920
      Top             =   0
   End
   Begin VB.CommandButton Command3 
      Caption         =   "Clear"
      Height          =   255
      Left            =   4200
      TabIndex        =   4
      Top             =   1080
      Width           =   1215
   End
   Begin VB.Label Label2 
      Caption         =   "Password to crack"
      Height          =   255
      Left            =   120
      TabIndex        =   3
      Top             =   120
      Width           =   1455
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'Cameron Bergh - www.nerdwareinc.com

'http://4.41.1.162/

'the maximum length for the password is 64 but you
'could change it to whatever you wanted
'this program also uses ASCII chars 97 to 122 (a - z)
'you could change it to use all possible ascii chars (1 - 255)
Dim Code(0 To 64) As String
Dim Password As String
Dim Time As Integer

Private Sub Command1_Click()
Timer1.Enabled = True
End Sub

Private Sub Command2_Click()
Timer1.Enabled = False
End Sub

Private Sub Command3_Click()
Dim Check As Integer

For Check = 0 To 64
    Code(Check) = 95
Next Check
End Sub

Private Sub Form_Load()
Dim Check As Integer

For Check = 0 To 64
    Code(Check) = 95
Next Check

End Sub

Private Sub Timer1_Timer()
Dim Speed As Integer
Dim Check As Integer

Time = Time + 5

For Speed = 0 To Slider1.Value

    Password = ""
    
    Code(0) = Code(0) + 1

    For Check = 0 To 64
        If Code(Check) = 95 Then
            
        Else
            Password = Password & Chr(Code(Check) + 1)
        End If
    Next Check

    For Check = 0 To 64
        If Code(Check) + 1 = 122 Then
            Code(Check) = 95
            Code(Check + 1) = Code(Check + 1) + 1
        End If
    Next Check
    
    Me.Caption = "Cracking Engine - " & Password
    
    If UCase(Text2.Text) = UCase(Password) Then
        MsgBox "Found your password.", vbInformation, "Cracked"
        Timer1.Enabled = False
        Exit Sub
    End If
    
Next Speed
End Sub
