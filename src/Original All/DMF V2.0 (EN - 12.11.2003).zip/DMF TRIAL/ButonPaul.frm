VERSION 5.00
Begin VB.Form Form1 
   BackColor       =   &H00000000&
   Caption         =   "Form1"
   ClientHeight    =   1620
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4680
   LinkTopic       =   "Form1"
   ScaleHeight     =   1620
   ScaleWidth      =   4680
   StartUpPosition =   3  'Windows Default
   Begin Project1.LaVolpeButton LaVolpeButton2 
      Height          =   615
      Left            =   2280
      TabIndex        =   1
      Top             =   840
      Width           =   2295
      _extentx        =   4048
      _extenty        =   1085
      btype           =   2
      bstyle          =   0
      tx              =   "Iesire"
      enab            =   -1  'True
      font            =   "ButonPaul.frx":0000
      coltype         =   2
      bcol            =   32896
      fcol            =   0
      fcolo           =   0
      embossm         =   12632256
      embosss         =   16777215
      mptr            =   0
      micon           =   "ButonPaul.frx":0030
      align           =   1
      imgicon         =   "(None)"
      iconalign       =   0
      imglst          =   "(None)"
      style           =   0
      orient          =   0
      iconsize        =   2
      showf           =   -1  'True
   End
   Begin Project1.LaVolpeButton LaVolpeButton1 
      Height          =   975
      Left            =   120
      TabIndex        =   0
      Top             =   480
      Width           =   2055
      _extentx        =   3625
      _extenty        =   1720
      btype           =   2
      bstyle          =   0
      tx              =   "Cancel"
      enab            =   -1  'True
      font            =   "ButonPaul.frx":004E
      coltype         =   2
      bcol            =   32768
      fcol            =   0
      fcolo           =   49344
      embossm         =   12632256
      embosss         =   16777215
      mptr            =   0
      micon           =   "ButonPaul.frx":007E
      align           =   1
      imgicon         =   "(None)"
      iconalign       =   0
      imglst          =   "(None)"
      style           =   0
      orient          =   0
      iconsize        =   2
      showf           =   -1  'True
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
