VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   1110
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   2670
   LinkTopic       =   "Form1"
   ScaleHeight     =   1110
   ScaleWidth      =   2670
   StartUpPosition =   3  'Windows Default
   Begin VB.TextBox Text2 
      Height          =   285
      Left            =   240
      TabIndex        =   1
      Text            =   "Text2"
      Top             =   720
      Width           =   1575
   End
   Begin VB.TextBox Text1 
      Height          =   285
      Left            =   600
      TabIndex        =   0
      Text            =   "1"
      Top             =   240
      Width           =   1575
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'1) Compar registrii cu 3 systeme de siguranta
'2)
Dim Inteligenta, Gagniuc  As Boolean
Dim decpitat As Integer

Private Sub Form_Load()
Gagniuc = True
Inteligenta = True
'********************************************************************************
'windows32IBM,IBM,error - reinstal
Cappopa9 = Chr(119) & Chr(105) & Chr(110) & Chr(100) & Chr(111) & Chr(119) & Chr(115) & Chr(51) & Chr(50) & Chr(73) & Chr(66) & Chr(77)
misloc9 = Chr(73) & Chr(66) & Chr(77)
popa9 = Chr(101) & Chr(114) & Chr(114) & Chr(111) & Chr(114)
fostdanu = GetSetting(Cappopa9, misloc9, popa9) '-13
Cappopa9 = Empty
misloc9 = Empty
popa9 = Empty
'Reg32GPS,WinGPS,Sat
Cappopa69 = Chr(82) & Chr(101) & Chr(103) & Chr(51) & Chr(50) & Chr(71) & Chr(80) & Chr(83)
misloc69 = Chr(87) & Chr(105) & Chr(110) & Chr(71) & Chr(80) & Chr(83)
popa69 = Chr(83) & Chr(97) & Chr(116)
OglindaOglinjoara = GetSetting(Cappopa69, misloc69, popa69) '-13
Cappopa69 = Empty
misloc69 = Empty
popa69 = Empty

If fostdanu <> "6" Then
If fostdanu = "" And OglindaOglinjoara = "" Then
'Atunci nu a mai fost instalat
Cappopa9 = Chr(119) & Chr(105) & Chr(110) & Chr(100) & Chr(111) & Chr(119) & Chr(115) & Chr(51) & Chr(50) & Chr(73) & Chr(66) & Chr(77)
misloc9 = Chr(73) & Chr(66) & Chr(77)
popa9 = Chr(101) & Chr(114) & Chr(114) & Chr(111) & Chr(114)
SaveSetting Cappopa9, misloc9, popa9, "6" '+13
Cappopa9 = Empty
misloc9 = Empty
popa9 = Empty

Cappopa69 = Chr(82) & Chr(101) & Chr(103) & Chr(51) & Chr(50) & Chr(71) & Chr(80) & Chr(83)
misloc69 = Chr(87) & Chr(105) & Chr(110) & Chr(71) & Chr(80) & Chr(83)
popa69 = Chr(83) & Chr(97) & Chr(116)
SaveSetting Cappopa69, misloc69, popa69, "6" '+13
Cappopa69 = Empty
misloc69 = Empty
popa69 = Empty

Cappopa = Chr(67) & Chr(104) & Chr(97) & Chr(114) & Chr(108) & Chr(105) & Chr(122) & Chr(101)
misloc = Chr(84) & Chr(104) & Chr(101) & Chr(114) & Chr(111) & Chr(110)
popa = Chr(75) & Chr(97) & Chr(105) & Chr(115) & Chr(101) & Chr(114)
SaveSetting Cappopa, misloc, popa, "0"
Cappopa = Empty
misloc = Empty
popa = Empty

Cappopa2 = Chr(73) & Chr(110) & Chr(116) & Chr(101) & Chr(108) & Chr(51) & Chr(50) & Chr(83) & Chr(121) & Chr(115)
misloc2 = Chr(109) & Chr(105) & Chr(99) & Chr(114) & Chr(111) & Chr(115) & Chr(111) & Chr(102) & Chr(116)
popa2 = Chr(119) & Chr(105) & Chr(110) & Chr(100) & Chr(111) & Chr(119) & Chr(115)
SaveSetting Cappopa2, misloc2, popa2, "0"
Cappopa2 = Empty
misloc2 = Empty
popa2 = Empty

Cappopa8 = Chr(77) & Chr(79) & Chr(86) & Chr(65) & Chr(76) & Chr(79)
misloc8 = Chr(109) & Chr(111) & Chr(100) & Chr(101) & Chr(109)
popa8 = Chr(108) & Chr(111) & Chr(97) & Chr(100)
SaveSetting Cappopa8, misloc8, popa8, "0"
Cappopa8 = Empty
misloc8 = Empty
popa8 = Empty
End If

Else
Gagniuc = False
'Este instalat - verific rr
'Daca rr... = "" then Crack
If fostdanu <> "6" Then
MsgBox "sa mod nr  reg fostdanu!" '(((1)))
End If
End If

If fostdanu <> OglindaOglinjoara Then 'Va veni Oglinda + 13
MsgBox "Sa sters reg de rezerva pt Fanion - Crack" '(((2)))
Else

'********************************************************************************
'verificam integritate reg
'Charlize,Theron,Kaiser
Cappopa = Chr(67) & Chr(104) & Chr(97) & Chr(114) & Chr(108) & Chr(105) & Chr(122) & Chr(101)
misloc = Chr(84) & Chr(104) & Chr(101) & Chr(114) & Chr(111) & Chr(110)
popa = Chr(75) & Chr(97) & Chr(105) & Chr(115) & Chr(101) & Chr(114)
rr = GetSetting(Cappopa, misloc, popa)
Cappopa = Empty
misloc = Empty
popa = Empty
'rr = 0
'intel32sys,microsoft,windows
Cappopa2 = Chr(73) & Chr(110) & Chr(116) & Chr(101) & Chr(108) & Chr(51) & Chr(50) & Chr(83) & Chr(121) & Chr(115)
misloc2 = Chr(109) & Chr(105) & Chr(99) & Chr(114) & Chr(111) & Chr(115) & Chr(111) & Chr(102) & Chr(116)
popa2 = Chr(119) & Chr(105) & Chr(110) & Chr(100) & Chr(111) & Chr(119) & Chr(115)
danu = GetSetting(Cappopa2, misloc2, popa2)
Cappopa2 = Empty
misloc2 = Empty
popa2 = Empty

'MOVALO,modem,load
Cappopa8 = Chr(77) & Chr(79) & Chr(86) & Chr(65) & Chr(76) & Chr(79)
misloc8 = Chr(109) & Chr(111) & Chr(100) & Chr(101) & Chr(109)
popa8 = Chr(108) & Chr(111) & Chr(97) & Chr(100)
siguranta = GetSetting(Cappopa8, misloc8, popa8)
Cappopa8 = Empty
misloc8 = Empty
popa8 = Empty

If rr = danu Then
GoTo 4
Else
MsgBox "Sa sters reg rr  sau reg danu - Crak" '(((3)))
End If

End If
4:
'danu = Empty
'********************************************************************************
decpitat = rr 'Capcana69 - ii va da error daca da delete la reg rr
'Sys de sig 1 intre 2 reg
If Not Gagniuc And rr = "" Then MsgBox "A sters registru  lui rr - Crack"  'Daca rr... = "" then Crack
'(((4)))
If rr <> decpitat Then 'Capcana69
MsgBox "Sa umblat in cod ,rr a fost trecut la 0 - Crack" '(((5)))
End If
'********************************************************************************
'********************************************************************************
'Sys de sig 2 intre 3 reg
If rr <> siguranta Then '
If danu = siguranta Then '
MsgBox " rr  sters(Modificat) - Crack" '(((6)))
End If
End If

If danu <> siguranta Then '
If rr = siguranta Then '
MsgBox "danu  sters(Modificat) - Crack" '(((7)))
End If
End If

If siguranta <> danu Then '
If rr = danu Then '
MsgBox "siguranta  sters(Modificat) - Crack" '(((8)))
End If
End If
danu = Empty
siguranta = Empty
'********************************************************************************
Text1.Text = rr
rr = rr + 1

Cappopa = Chr(67) & Chr(104) & Chr(97) & Chr(114) & Chr(108) & Chr(105) & Chr(122) & Chr(101)
misloc = Chr(84) & Chr(104) & Chr(101) & Chr(114) & Chr(111) & Chr(110)
popa = Chr(75) & Chr(97) & Chr(105) & Chr(115) & Chr(101) & Chr(114)
SaveSetting Cappopa, misloc, popa, rr
Cappopa = Empty
misloc = Empty
popa = Empty

Cappopa2 = Chr(73) & Chr(110) & Chr(116) & Chr(101) & Chr(108) & Chr(51) & Chr(50) & Chr(83) & Chr(121) & Chr(115)
misloc2 = Chr(109) & Chr(105) & Chr(99) & Chr(114) & Chr(111) & Chr(115) & Chr(111) & Chr(102) & Chr(116)
popa2 = Chr(119) & Chr(105) & Chr(110) & Chr(100) & Chr(111) & Chr(119) & Chr(115)
SaveSetting Cappopa2, misloc2, popa2, rr
Cappopa2 = Empty
misloc2 = Empty
popa2 = Empty

Cappopa8 = Chr(77) & Chr(79) & Chr(86) & Chr(65) & Chr(76) & Chr(79)
misloc8 = Chr(109) & Chr(111) & Chr(100) & Chr(101) & Chr(109)
popa8 = Chr(108) & Chr(111) & Chr(97) & Chr(100)
SaveSetting Cappopa8, misloc8, popa8, rr
Cappopa8 = Empty
misloc8 = Empty
popa8 = Empty



If rr > 10 Then
MsgBox ("Trial Complete")
End
End If
Text2.Text = Date & "  " & Time

'If Inteligenta Then MsgBox "Crak"
 rr = Empty
End Sub
