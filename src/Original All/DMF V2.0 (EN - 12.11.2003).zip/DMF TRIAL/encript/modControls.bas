Attribute VB_Name = "modControls"
Public ctlDBobjects As Control


'***************************************
' Create a Public Control that will
' be used to set enable and dissable
' properties of the forms controls by
' the use of the TAG property
'***************************************

Public Sub Enable_Code_Controls()
  
    'Loop that locates Navigation Buttons then Dissables them
    For Each ctlDBobjects In frmMain.Controls
        If InStr(ctlDBobjects.Tag, "Code") > 0 Then
          ctlDBobjects.Enabled = True
            With frmMain
              .cmdEncrypt.Enabled = False
              .cmdOpen.Enabled = False
              .cmdClear.Enabled = False
            End With
        End If
    Next ctlDBobjects
  
End Sub

Public Sub Dissable_Code_Controls()
  
    'Loop that locates Navigation Buttons then Dissables them
    For Each ctlDBobjects In frmMain.Controls
        If InStr(ctlDBobjects.Tag, "Code") > 0 Then
          ctlDBobjects.Enabled = False
        End If
        With frmMain
              .cmdEncrypt.Enabled = True
              .cmdOpen.Enabled = True
              .cmdClear.Enabled = True
        End With
    Next ctlDBobjects
  
End Sub

