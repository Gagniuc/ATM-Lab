VERSION 5.00
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#1.3#0"; "COMCTL32.OCX"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Begin VB.Form frmMain 
   BorderStyle     =   0  'None
   Caption         =   "Form1"
   ClientHeight    =   4305
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   7035
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Picture         =   "frmMain.frx":0000
   ScaleHeight     =   4305
   ScaleWidth      =   7035
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton cmdClear 
      Caption         =   "cls."
      Height          =   375
      Left            =   5160
      TabIndex        =   21
      Top             =   3360
      Width           =   495
   End
   Begin VB.Timer TimeTrue 
      Interval        =   1000
      Left            =   120
      Top             =   4800
   End
   Begin VB.TextBox txtCode 
      Alignment       =   1  'Right Justify
      BackColor       =   &H00FFFFFF&
      Enabled         =   0   'False
      ForeColor       =   &H00000000&
      Height          =   315
      Left            =   600
      MaxLength       =   6
      TabIndex        =   15
      Tag             =   "Code"
      Top             =   1440
      Width           =   990
   End
   Begin VB.CommandButton cmdOpen 
      Caption         =   "Open File"
      Height          =   375
      Left            =   3840
      TabIndex        =   14
      Top             =   3360
      Width           =   1215
   End
   Begin VB.CommandButton cmdEncrypt 
      Caption         =   "Encrypt"
      Height          =   375
      Left            =   2520
      TabIndex        =   13
      Top             =   3360
      Width           =   1215
   End
   Begin VB.CommandButton cmdEnter 
      Caption         =   "Enter"
      Enabled         =   0   'False
      Height          =   300
      Left            =   960
      TabIndex        =   12
      Tag             =   "Code"
      Top             =   2880
      Width           =   660
   End
   Begin VB.CommandButton cmdNumber 
      Caption         =   "7"
      Enabled         =   0   'False
      Height          =   300
      Index           =   7
      Left            =   600
      TabIndex        =   11
      Tag             =   "Code"
      Top             =   1800
      Width           =   300
   End
   Begin VB.CommandButton cmdNumber 
      Caption         =   "4"
      Enabled         =   0   'False
      Height          =   300
      Index           =   4
      Left            =   600
      TabIndex        =   10
      Tag             =   "Code"
      Top             =   2160
      Width           =   300
   End
   Begin VB.CommandButton cmdNumber 
      Caption         =   "1"
      Enabled         =   0   'False
      Height          =   300
      Index           =   1
      Left            =   600
      TabIndex        =   9
      Tag             =   "Code"
      Top             =   2520
      Width           =   300
   End
   Begin VB.CommandButton cmdNumber 
      Caption         =   "8"
      Enabled         =   0   'False
      Height          =   300
      Index           =   8
      Left            =   960
      TabIndex        =   8
      Tag             =   "Code"
      Top             =   1800
      Width           =   300
   End
   Begin VB.CommandButton cmdNumber 
      Caption         =   "9"
      Enabled         =   0   'False
      Height          =   300
      Index           =   9
      Left            =   1320
      TabIndex        =   7
      Tag             =   "Code"
      Top             =   1800
      Width           =   300
   End
   Begin VB.CommandButton cmdNumber 
      Caption         =   "5"
      Enabled         =   0   'False
      Height          =   300
      Index           =   5
      Left            =   960
      TabIndex        =   6
      Tag             =   "Code"
      Top             =   2160
      Width           =   300
   End
   Begin VB.CommandButton cmdNumber 
      Caption         =   "6"
      Enabled         =   0   'False
      Height          =   300
      Index           =   6
      Left            =   1320
      TabIndex        =   5
      Tag             =   "Code"
      Top             =   2160
      Width           =   300
   End
   Begin VB.CommandButton cmdNumber 
      Caption         =   "2"
      Enabled         =   0   'False
      Height          =   300
      Index           =   2
      Left            =   960
      TabIndex        =   4
      Tag             =   "Code"
      Top             =   2520
      Width           =   300
   End
   Begin VB.CommandButton cmdNumber 
      Caption         =   "3"
      Enabled         =   0   'False
      Height          =   300
      Index           =   3
      Left            =   1320
      TabIndex        =   3
      Tag             =   "Code"
      Top             =   2520
      Width           =   300
   End
   Begin VB.CommandButton cmdNumber 
      Caption         =   "0"
      Enabled         =   0   'False
      Height          =   300
      Index           =   0
      Left            =   600
      TabIndex        =   2
      Tag             =   "Code"
      Top             =   2880
      Width           =   300
   End
   Begin MSComDlg.CommonDialog CDialog1 
      Left            =   3960
      Top             =   4320
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin ComctlLib.ProgressBar PrgTime 
      Height          =   135
      Left            =   360
      TabIndex        =   1
      Top             =   3960
      Visible         =   0   'False
      Width           =   4455
      _ExtentX        =   7858
      _ExtentY        =   238
      _Version        =   327682
      Appearance      =   1
   End
   Begin VB.Timer Timer1 
      Enabled         =   0   'False
      Interval        =   1
      Left            =   960
      Top             =   4800
   End
   Begin VB.Timer Timer2 
      Enabled         =   0   'False
      Interval        =   1
      Left            =   1440
      Top             =   4800
   End
   Begin VB.Timer Timer3 
      Enabled         =   0   'False
      Interval        =   1
      Left            =   1920
      Top             =   4800
   End
   Begin VB.Timer Timer4 
      Enabled         =   0   'False
      Interval        =   1
      Left            =   2400
      Top             =   4800
   End
   Begin VB.Timer Timer5 
      Enabled         =   0   'False
      Interval        =   1
      Left            =   2880
      Top             =   4800
   End
   Begin VB.Timer Timer6 
      Enabled         =   0   'False
      Interval        =   1
      Left            =   3360
      Top             =   4800
   End
   Begin VB.Timer Timer7 
      Enabled         =   0   'False
      Interval        =   1
      Left            =   3840
      Top             =   4800
   End
   Begin VB.Timer Timer8 
      Enabled         =   0   'False
      Interval        =   1
      Left            =   4320
      Top             =   4800
   End
   Begin VB.Timer Timer9 
      Enabled         =   0   'False
      Interval        =   1
      Left            =   4800
      Top             =   4800
   End
   Begin VB.Timer Timer10 
      Enabled         =   0   'False
      Interval        =   1
      Left            =   5280
      Top             =   4800
   End
   Begin VB.Timer Timer11 
      Enabled         =   0   'False
      Interval        =   1
      Left            =   5760
      Top             =   4800
   End
   Begin VB.TextBox txtInput 
      Height          =   2535
      Left            =   1680
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   0
      Top             =   720
      Width           =   5055
   End
   Begin VB.Label lblMe 
      BackStyle       =   0  'Transparent
      Caption         =   "Programmed by: -dd214"
      ForeColor       =   &H00FFFFFF&
      Height          =   255
      Left            =   360
      TabIndex        =   20
      Top             =   3600
      Width           =   1815
   End
   Begin VB.Label lblName 
      BackStyle       =   0  'Transparent
      Caption         =   "A Brannon Binary Solution"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   255
      Left            =   120
      TabIndex        =   19
      Top             =   3360
      Width           =   2415
   End
   Begin VB.Label lblTime 
      BackStyle       =   0  'Transparent
      Height          =   255
      Left            =   5880
      TabIndex        =   18
      Top             =   3720
      Width           =   1095
   End
   Begin VB.Label lblFile 
      BackStyle       =   0  'Transparent
      ForeColor       =   &H00FFFFFF&
      Height          =   255
      Left            =   1680
      TabIndex        =   17
      Top             =   480
      Width           =   5055
   End
   Begin VB.Label lblTitle 
      BackStyle       =   0  'Transparent
      Caption         =   "File Encryptor"
      Height          =   375
      Left            =   240
      TabIndex        =   16
      Top             =   240
      Width           =   975
   End
   Begin VB.Image Image11 
      Height          =   210
      Left            =   6720
      Picture         =   "frmMain.frx":9909
      Top             =   3960
      Width           =   120
   End
   Begin VB.Image Image10 
      Height          =   210
      Left            =   6600
      Picture         =   "frmMain.frx":9BAC
      Top             =   3960
      Width           =   120
   End
   Begin VB.Image Image9 
      Height          =   210
      Left            =   6480
      Picture         =   "frmMain.frx":9E4F
      Top             =   3960
      Width           =   120
   End
   Begin VB.Image Image8 
      Height          =   210
      Left            =   6360
      Picture         =   "frmMain.frx":A0F2
      Top             =   3960
      Width           =   120
   End
   Begin VB.Image Image7 
      Height          =   210
      Left            =   6240
      Picture         =   "frmMain.frx":A395
      Top             =   3960
      Width           =   120
   End
   Begin VB.Image Image6 
      Height          =   210
      Left            =   6120
      Picture         =   "frmMain.frx":A638
      Top             =   3960
      Width           =   120
   End
   Begin VB.Image Image5 
      Height          =   210
      Left            =   6000
      Picture         =   "frmMain.frx":A8DB
      Top             =   3960
      Width           =   120
   End
   Begin VB.Image Image4 
      Height          =   210
      Left            =   5880
      Picture         =   "frmMain.frx":AB7E
      Top             =   3960
      Width           =   120
   End
   Begin VB.Image Image3 
      Height          =   210
      Left            =   5760
      Picture         =   "frmMain.frx":AE21
      Top             =   3960
      Width           =   120
   End
   Begin VB.Image Image2 
      Height          =   210
      Left            =   5640
      Picture         =   "frmMain.frx":B0C4
      Top             =   3960
      Width           =   120
   End
   Begin VB.Image Image1 
      Height          =   210
      Left            =   5520
      Picture         =   "frmMain.frx":B367
      Top             =   3960
      Width           =   120
   End
   Begin VB.Image imgClose 
      Height          =   330
      Left            =   5880
      Picture         =   "frmMain.frx":B60A
      Top             =   50
      Width           =   390
   End
   Begin VB.Image imgsrc 
      Height          =   210
      Index           =   1
      Left            =   2400
      Picture         =   "frmMain.frx":B9C1
      Top             =   2520
      Visible         =   0   'False
      Width           =   120
   End
   Begin VB.Image imgsrc 
      Height          =   210
      Index           =   0
      Left            =   2160
      Picture         =   "frmMain.frx":BC6B
      Top             =   2520
      Visible         =   0   'False
      Width           =   120
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'////////////////////////////////////////////
' |                                        | |
' \                                       / /
'  \     BRANNON BINARY SOLUTIONS        / /
'   \                                   / /
'    \-    So Much Code...             / /
'   / | \     So Few To Write It!   _ /_/
'  /  |  \                         / /        |
' /  |-\  \-- ===================/  /     __ /
'/   |     \ \==================/ /      /  /
'    |      \ \==================/      /   / |
'   |        \ \=============================/
'   |         \ \===========================/
'###############################################################################################

'All variables must be Declared.
Option Explicit

Dim dblmax, dblmin, dblTimeStatus As Double
Dim intCount As Integer

'Declarations to see if user is opening or saving file *******************
Dim blnselect As Boolean

'Declarations for Code Input *******************
Dim strOperation, strX, strY As String
Dim intCheck As Integer

Private Sub cmdClear_Click()
    txtInput.Text = ""
    txtInput.SetFocus
End Sub

Private Sub cmdEncrypt_Click()
Dim dblCodeKey As Double
Dim strPrompt, strMessage, strV As String

blnselect = True
strPrompt = "Please Enter Encryption Code"
strMessage = MsgBox(strPrompt, vbOKOnly + vbInformation, "Code")
If strMessage = vbOK And txtInput.Text <> "" Then
    
    'PUT IN ENABLE CODE HERE
    Enable_Code_Controls
        Else
         strV = MsgBox("Please enter text to be encrypted.", vbOKOnly + vbExclamation, "Enter Text")
         txtInput.SetFocus
End If

End Sub

Private Sub cmdEnter_Click()
    Dim strCodeKey, strDecriptor, strX As String
    Dim NumStrIn, FocusCharacter As String
    Dim intX As Integer
    Dim lngNum As Long
    
    If blnselect = True Then
    
    PrgTime.Visible = True
    
    CDialog1.Filter = "Text files (*.TXT)|*.TXT"
    CDialog1.ShowSave      'display Save dialog
    If CDialog1.FileName <> "" Then
        '*********************************************
        ' Use the code key the user selects to encrypt
        ' the file.  This helps decrease the risk of
        ' a code crack.
        '*********************************************
        strCodeKey = txtCode.Text
            If strCodeKey = "" Then Exit Sub  'if Cancel chosen, exit sub
                frmMain.MousePointer = 11     'display hourglass
                NumStrIn = Len(txtInput.Text) 'find string length
                PrgTime.Max = NumStrIn
                    '**************************************
                    ' Open the file and for each character that
                    ' exist, read in its value.
                    '**************************************
                    Open CDialog1.FileName For Output As #1
                For intX = 1 To NumStrIn
                    FocusCharacter = Mid(txtInput.Text, intX, 1)
                    '**************************************
                    ' Use vb built in function Asc to read
                    ' character then use Xor to encrypt the number.
                    '**************************************
            Print #1, Asc(FocusCharacter) Xor strCodeKey;
            intCount = intCount + 1
            PrgTime.Value = intCount
        Next intX
        Close #1                      '/
        CDialog1.FileName = ""        '/
        frmMain.MousePointer = 0      '/ Some House keeping
    End If                            '/ used to manage file connection and
      PrgTime.Value = 0               '/ clean up the form for next use.
      intCount = 0                    '/
      txtCode.Text = ""               '/
      strOperation = 0                '/
      strX = 0                        '/
      strY = 0                        '/
      intCheck = 0                    '/
        Beep
        Dissable_Code_Controls
        PrgTime.Visible = False
        
        Else
        
        PrgTime.Visible = True
         CDialog1.Filter = "Text files (*.TXT)|*.TXT"
            CDialog1.ShowOpen
            If CDialog1.FileName <> "" Then
            '*********************************************
            ' Use code key from user then use the key
            ' to convert the text file to its original
            ' text.
            '*********************************************
                strCodeKey = txtCode.Text
                'User may not enter a key...so exit the procedure!
                If strCodeKey = "" Then Exit Sub
                  frmMain.MousePointer = 11
                    '*********************************************
                    ' Open each string in the file an decrypt it
                    ' by use of Xor function and our user's
                    ' secret key code.  There is no way to check
                    ' is key code is correct, so if it is incorrect
                    ' the user will see allot of scrambled characters
                    ' in txtInput.
                    '*********************************************
                    Open CDialog1.FileName For Input As #1
                        On Error GoTo Problem: 'Controls errors
                        strDecriptor = ""
                  Do Until EOF(1)
                      Input #1, lngNum
                      strX = Chr(lngNum Xor strCodeKey)
                      strDecriptor = strDecriptor & strX
                  Loop
                    'display location of file being read to user...
                    lblFile.Caption = CDialog1.FileName
                    txtInput.Text = strDecriptor
                    txtInput.Enabled = True  '
CleanUp:
                    frmMain.MousePointer = 0  '/
                    Close #1                  '/  House Keeping
                    CDialog1.FileName = ""    '/
                End If
                  Beep
                  intCount = 0                    '/
                  txtCode.Text = ""               '/
                  strOperation = 0                '/ House Keeping
                  strX = 0                        '/
                  strY = 0                        '/
                  intCheck = 0                    '/
                    Beep
                        Dissable_Code_Controls
                        PrgTime.Visible = False
    Exit Sub
Problem:
    If Err.Number = 5 Then
        MsgBox ("Incorrect Encryption Key")
        intCount = 0                    '/
        txtCode.Text = ""               '/
        strOperation = 0                '/
        strX = 0                        '/ House Keeping
        strY = 0                        '/
        intCheck = 0                    '/
    Else
        MsgBox "Error Opening File", , Err.Description
        intCount = 0                    '/
        txtCode.Text = ""               '/
        strOperation = 0                '/ House Keeping
        strX = 0                        '/
        strY = 0                        '/
        intCheck = 0                    '/
    End If
    Resume CleanUp:
            
        
    End If
End Sub

Private Sub cmdNumber_Click(Index As Integer)

On Error GoTo Error2


    If intCheck = 1 Then
        strX = ""
        strY = ""
        strOperation = ""
        intCheck = 0
    End If

    If strOperation = "" Then              '| If a mathematical operation has not
        strX = Str(Val(strX & Str(Index))) '|   been selected then strX is assigned
        txtCode.Text = strX             '|   the value of which ever index is used.
      Else                                 '| Otherwise
        strY = Str(Val(strY & Str(Index))) '|   strY is assigned the value of the
        txtCode.Text = strY             '|   index used.
    End If                                 '|
                                           '| Exp: cmdNumber(5) is pressed, so
                                           '|      Val(5) is assigned to the
                                           '|      declaration.
    Exit Sub 'STOP! do not fall to
             '     error unless
             '     there is one.
Error2:
    txtCode.Text = "  -Error-  "
    strX = ""
    strY = ""
    strOperation = ""
    
End Sub

Private Sub cmdOpen_Click()
   Dim strDecry As String
    
    strDecry = MsgBox("Please enter Decryption code.", vbOKOnly + vbInformation, "Enter Code")
      Enable_Code_Controls
      txtInput.Text = ""
      blnselect = False
End Sub

Private Sub Form_Load()
    Timer1.Enabled = True
        With frmMain
            .cmdClear.ToolTipText = "Clears Input Screen."
            .cmdEncrypt.ToolTipText = "Prepares text to be encrypted."
            .cmdOpen.ToolTipText = "Search for encrypted file."
            .txtInput.ToolTipText = "Enter text to be encrypted."
            .txtCode.ToolTipText = "Remember this code for future file decryption."
            .imgClose.ToolTipText = "Close"
        End With
End Sub

Private Sub imgClose_Click()
    Unload frmMain
    Set frmMain = Nothing
End Sub

Private Sub lblEncrypt_Click()
    imgEncrypt_Click
End Sub

Private Sub lblOpen_Click()
    imgOpen_Click
End Sub


'$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
' Ok, I may have gone a little overboard here, but this
' is the logic that drives the ACTIVE BAR that you see
' moving all the time.  The Logic of this code is each
' timer is linked to an image, and that image is switched
' each time the timer's interval is summoned.  This can work
' within a loop; however, the difference in processor speed
' varies the outcome of the appearance.
'$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
Private Sub Timer1_Timer()
    
    If Image1.Picture = imgsrc(1) Then
        Image1.Picture = imgsrc(0)
         Else
            Image1.Picture = imgsrc(1)
    End If
    
    Timer1.Enabled = False
    Timer2.Enabled = True
End Sub

Private Sub Timer10_Timer()
    If Image10.Picture = imgsrc(1) Then
        Image10.Picture = imgsrc(0)
         Else
            Image10.Picture = imgsrc(1)
    End If
    
    Timer10.Enabled = False
    Timer11.Enabled = True
End Sub

Private Sub Timer11_Timer()
    If Image11.Picture = imgsrc(1) Then
        Image11.Picture = imgsrc(0)
         Else
            Image11.Picture = imgsrc(1)
    End If
    
    Timer11.Enabled = False
    Timer1.Enabled = True
End Sub

Private Sub Timer2_Timer()
    If Image2.Picture = imgsrc(1) Then
        Image2.Picture = imgsrc(0)
         Else
            Image2.Picture = imgsrc(1)
    End If
    
    Timer2.Enabled = False
    Timer3.Enabled = True
End Sub

Private Sub Timer3_Timer()
    If Image3.Picture = imgsrc(1) Then
        Image3.Picture = imgsrc(0)
         Else
            Image3.Picture = imgsrc(1)
    End If
    
    Timer3.Enabled = False
    Timer4.Enabled = True
End Sub

Private Sub Timer4_Timer()
    If Image4.Picture = imgsrc(1) Then
        Image4.Picture = imgsrc(0)
         Else
            Image4.Picture = imgsrc(1)
    End If
    
    Timer4.Enabled = False
    Timer5.Enabled = True
End Sub

Private Sub Timer5_Timer()
    If Image5.Picture = imgsrc(1) Then
        Image5.Picture = imgsrc(0)
         Else
            Image5.Picture = imgsrc(1)
    End If
    
    Timer5.Enabled = False
    Timer6.Enabled = True
End Sub

Private Sub Timer6_Timer()
    If Image6.Picture = imgsrc(1) Then
        Image6.Picture = imgsrc(0)
         Else
            Image6.Picture = imgsrc(1)
    End If
    
    Timer6.Enabled = False
    Timer7.Enabled = True
End Sub

Private Sub Timer7_Timer()
    If Image7.Picture = imgsrc(1) Then
        Image7.Picture = imgsrc(0)
         Else
            Image7.Picture = imgsrc(1)
    End If
    
    Timer7.Enabled = False
    Timer8.Enabled = True
End Sub

Private Sub Timer8_Timer()
    If Image8.Picture = imgsrc(1) Then
        Image8.Picture = imgsrc(0)
         Else
            Image8.Picture = imgsrc(1)
    End If
    
    Timer8.Enabled = False
    Timer9.Enabled = True
End Sub

Private Sub Timer9_Timer()
    If Image9.Picture = imgsrc(1) Then
        Image9.Picture = imgsrc(0)
         Else
            Image9.Picture = imgsrc(1)
    End If
    
    Timer9.Enabled = False
    Timer10.Enabled = True
End Sub

Private Sub TimeTrue_Timer()
    lblTime = Time
End Sub
